#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "hbt.h"
#include <string.h>

static void print_tree(Tnode* head)
{
    if(head == NULL)
        return;

    printf("%d", head -> key);
    char bal = 0;
    if(head -> right != NULL)
        bal += 1;
    if(head -> left != NULL)
        bal += 2;
    printf(" %d\n", bal);

    print_tree(head -> left);
    print_tree(head -> right);

    return;
}

static Tnode* CR(Tnode* ya)
{
    Tnode* A = ya;
    Tnode* B = ya -> left;
    Tnode* T2 = B -> right;

    B -> right = A;
    A -> left = T2;

    return B;
}

static Tnode* CCR(Tnode* ya)
{
    Tnode* A = ya;
    Tnode* B = ya -> right;
    Tnode* T2 = ya -> right -> left;

    B -> left = A;
    A -> right = T2;

    return B;
}

static Tnode* insert_to_tree(Tnode* new_node, Tnode* head)
{
    Tnode* pya = NULL;
    Tnode* ya = head;
    Tnode* curr = head;
    Tnode* pcurr = NULL;
    Tnode* q = NULL;
    bool top_level = false;

    while(curr != NULL)
    {
        if(new_node -> key > curr -> key)
            q = curr -> right;
        else
            q = curr -> left;

        // Update Youngest Ancestor
        
        if(q != NULL && q -> balance != 0)
        {
            pya = curr;
            ya = q;
        }
        
        pcurr = curr;
        curr = q;
    }

    if(ya == head)
        top_level = true;

    // Insert
    if(new_node -> key > pcurr -> key)
        pcurr -> right = new_node;
    else
        pcurr -> left = new_node;
    
    // Update Balance
    curr = ya;
    while(curr != new_node)
    {
        if(curr -> key > new_node -> key)
        {
            curr -> balance += 1;
            curr = curr -> left;
        }
        else
        {
            curr -> balance -= 1;
            curr = curr -> right;
        }
    }

    // Check If Rebalancing Is Nessecary

    if(ya -> balance > -2 && ya -> balance < 2)
        return head;
    
    // Find The Child Where The New Insertion Happend
    Tnode* child = NULL;
    if(new_node -> key > ya -> key)
        child = ya -> right;
    else
        child = ya -> left;
    // Rebalancing

    // Same Direction Rebalance
    if(ya -> balance == 2 && child -> balance == 1)
    {
        curr = CR(ya);
        ya -> balance = 0;
        child -> balance = 0;
    }
    if(ya -> balance == -2 && child -> balance == -1)
    {
        curr = CCR(ya);
        ya -> balance = 0;
        child -> balance = 0;
    }
    // Opposite Direction Rebalance
    if((ya -> balance == 2) && (child -> balance == -1))
    {
        ya -> left = CCR(child);
        curr = CR(ya);

        if(curr -> balance == 0)
        {
            ya -> balance = 0;
            child -> balance = 0;
        }
        else
        {
            if(curr -> balance == 1)
            {
                ya -> balance = -1;
                child -> balance = 0;
            }
            else
            {
                ya -> balance = 0;
                child -> balance = 1;
            }
            curr -> balance = 0; 
        }
    }

    if((ya -> balance = -2 && child -> balance == 1))
    {
        ya -> right = CR(child);
        curr = CCR(ya);

        if(curr -> balance == 0)
        {
            ya -> balance = 0;
            child -> balance = 0;
        }
        else
        {
            if(curr -> balance == -1)
            {
                ya -> balance = 1;
                child -> balance = 0;
            }
            else
            {
                ya -> balance = 0;
                child -> balance = -1;
            }
            curr -> balance = 0;
        }
    }
    
    if(pya == NULL)
        head = curr;
    else
        if(new_node -> key < pya -> key)
            pya -> left = curr;
        else
            pya -> right = curr;
    

    if(top_level)
        return curr;
    else
        return head;
}

static void write_to_file(Tnode* head, FILE* fp)
{
    if(head == NULL)
        return;

    // Access The Node

    int val = head -> key;
    fwrite(&val, sizeof(int), 1, fp);

    char links = 0;
    if(head -> right != NULL)
        links += 1;
    if(head -> left != NULL)
        links += 2;

    fputc(links, fp);
    
    // Traversal
    write_to_file(head -> left, fp);
    write_to_file(head -> right, fp);
    return;
}

static void free_tree(Tnode* head)
{
    if(head == NULL)
        return;

    free_tree(head -> left);
    free_tree(head -> right);
    free(head);

    return;
}

static Tnode* make_Tnode(int val)
{
    Tnode* new_tnode = malloc(sizeof(*new_tnode));
    *new_tnode = (Tnode){.key = val, .balance = 0, .left = NULL, .right = NULL};
    return new_tnode;     
}

static void read_file(FILE* fp, int* pass_ch, int* pass_int, int* val, char* operation)
{
    *pass_int = fread(val, sizeof(*val), 1, fp);
    *pass_ch = fread(operation, sizeof(*operation), 1, fp);
    return;
}

static void delete_element(Tnode* head, int key)
{
    // Recursive Function -- Terminating Condition Finding And Deleting The Node
    if(head == NULL) 
        return;

    if(head -> key == key)

    if(key > head -> key)
        delete_element(head -> right, key);
    if(key < head -> key)
        delete_element(head -> left, key);

    return;
}

int main(int argc, char* argv[])
{
    if(strcmp(argv[1], "-b") == 0)
    {
        FILE* fp = fopen(argv[2], "r");
        if(fp == NULL)
        {
            fprintf(stdout, "%d\n", -1);
            return EXIT_FAILURE;
        }

        int pass_int;
        int pass_ch;
        int val;
        char operation;

        read_file(fp, &pass_ch, &pass_int, &val, &operation);
        Tnode* head_node = make_Tnode(val);

        while(!feof(fp))
        {
            read_file(fp, &pass_ch, &pass_int, &val, &operation);
            if(pass_ch && pass_int)
            {
                if(operation == 'i')
                {
                    Tnode* new_tnode = make_Tnode(val);
                    head_node = insert_to_tree(new_tnode, head_node);
                }
                if(operation == 'd')
                {
                    delete_element(head_node, val);
                }
            }
        }
        fclose(fp);
        
        fp = fopen(argv[3], "w");
        if(fp == NULL)
            return EXIT_FAILURE;

        print_tree(head_node);

        write_to_file(head_node, fp);
        fclose(fp);
        free_tree(head_node);
        fprintf(stdout, "%d\n", 1);
        return EXIT_SUCCESS;     
    }
    if(strcmp(argv[1], "-e") == 0)
    {
        FILE* fp = fopen(argv[2], "r");
        if(fp == NULL)
        {
            fprintf(stdout, "%d\n", -1);
            return EXIT_FAILURE;
        }

    }
}
